export const products = [
  {id:1 , name:'피자' , price:20000, image:'./src/assets/img-1.png',category:'Best'},
  {id:2 , name:'햄버거' , price:8000, image:'./src/assets/img-2.png',category:'New'},
  {id:3 , name:'콜라' , price:3000, image:'./src/assets/img-3.png',category:'세트'},
  {id:4 , name:'감자튀김' , price:5000, image:'./src/assets/img-4.png',category:'음료'},
  {id:5 , name:'밀크쉐이크' , price:4000, image:'./src/assets/img-5.png',category:'디저트'}
];
export const categories = ['전체','Best','New','세트','음료','디저트'];
